$(document).ready(function() {
	console.log('javascript has loaded 2!')
})
