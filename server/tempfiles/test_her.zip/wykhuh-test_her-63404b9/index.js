$(document).ready(function() {
	console.log('javascript has loaded!')
})